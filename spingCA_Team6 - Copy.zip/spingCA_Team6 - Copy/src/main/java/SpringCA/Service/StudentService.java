package SpringCA.Service;

import SpringCA.entities.Student;

public interface StudentService {
	
	public Student updateStudent(int stduentId, Student student);

}
